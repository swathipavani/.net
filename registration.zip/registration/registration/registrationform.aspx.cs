﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace registration
{
    public partial class registrationform : System.Web.UI.Page
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            con.Open();
        }

      
            protected void BtnSave_Click(object sender, EventArgs e)
        {
            
            
            SqlCommand com = new SqlCommand("insert into Userinfo
 values('" + txtname.Text + "','" + txAddress.Text + "','" + txtEmailid.Text + "','" + txtmobile.Text + "')", con);

            
            txtname.Text = "";
            txAddress.Text = "";
            txtmobile.Text = "";
            txtmobile.Text = "";


            com.ExecuteNonQuery();
            
            
                con.Close();

            }
        }

    }


    
    
